/*
 * The default terminal device to open.  If undefined, it will be guessed
 * at compile time based on the OS.
 */
#undef DEFAULT_DEVICE
